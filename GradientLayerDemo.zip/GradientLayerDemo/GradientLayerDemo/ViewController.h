//
//  ViewController.h
//  GradientLayerDemo
//
//  Created by tiny on 16/7/25.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

