//
//  LGThirdPartySocial.h
//  PEDoctor
//
//  Created by 李新星 on 16/3/2.
//  Copyright © 2016年 EEGSmart. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  第三方登录及分享的类型
 */
typedef NS_ENUM(NSInteger, LGThirdPartySocialType){
    /**
     *  微信
     */
    LGThirdPartySocialTypeWechat = 1,
    /**
     *  qq
     */
    LGThirdPartySocialTypeQQ = 2,
    /**
     *  微博
     */
    LGThirdPartySocialTypeSinaWeibo = 3,
};


@interface LGThirdPartySocial : NSObject

@property (assign, nonatomic) LGThirdPartySocialType socialType;
@property (strong, nonatomic) NSString * imageName;

/*! 当前手机可使用的第三发平台 */
+ (NSArray *)enableThirdLoginPlatforms;

@end
