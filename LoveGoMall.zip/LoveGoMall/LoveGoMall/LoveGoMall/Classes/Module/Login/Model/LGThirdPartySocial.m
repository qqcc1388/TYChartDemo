//
//  LGThirdPartySocial.m
//  PEPatient
//
//  Created by 李新星 on 16/3/2.
//  Copyright © 2016年 EEGSmart. All rights reserved.
//

#import "LGThirdPartySocial.h"
//#import <WeiboSDK.h>
//#import <TencentOpenAPI/TencentOAuth.h>
//#import <WXApi.h>

@implementation LGThirdPartySocial

+ (NSArray *)enableThirdLoginPlatforms {
    
    NSMutableArray * resultArray = [NSMutableArray array];
    
//    if ([WXApi isWXAppInstalled]) {
//        ESThirdPartySocial * social = [ESThirdPartySocial new];
//        social.socialType = ESThirdPartySocialTypeWechat;
//        social.imageName = @"wechat_icon_nor";
//        [resultArray addObject:social];
//    }
//    
//    if ([TencentOAuth iphoneQQInstalled]) {
//        ESThirdPartySocial * social = [ESThirdPartySocial new];
//        social.socialType = ESThirdPartySocialTypeQQ;
//        social.imageName = @"qq_icon_nor";
//        [resultArray addObject:social];
//    }
//    
//    if ([WeiboSDK isWeiboAppInstalled]) {
//        ESThirdPartySocial * social = [ESThirdPartySocial new];
//        social.socialType = ESThirdPartySocialTypeSinaWeibo;
//        social.imageName = @"weibo_icon_nor";
//        [resultArray addObject:social];
//    }
    return [NSArray arrayWithArray:resultArray];
}

@end
