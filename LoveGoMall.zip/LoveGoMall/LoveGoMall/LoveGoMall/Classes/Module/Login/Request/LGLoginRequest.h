//
//  LGLoginRequest.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGRequest.h"

@interface LGLoginRequest : LGRequest


- (instancetype)initWithAccount:(NSString *)account password:(NSString *)pwd;

/**
 *  手机号（用户名）必填
 */
@property (strong, nonatomic) NSString * account;

/**
 *  密码  必填
 */
@property (strong, nonatomic) NSString * pwd;



@end
