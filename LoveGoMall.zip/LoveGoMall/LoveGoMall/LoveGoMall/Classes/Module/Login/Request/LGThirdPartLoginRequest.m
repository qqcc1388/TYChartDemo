//
//  LGThirdPartRequest.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGThirdPartLoginRequest.h"

@implementation LGThirdPartLoginRequest



- (NSString *)requestUrl {
    return @"/doctor/sdkauth";
}

- (id)requestArgument {
    
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    
    //第三方ID
    if (_thirdLoginType == LGThirdPartySocialTypeQQ) {
        [dic setObject:@"qq" forKey:@"pf"];
    }
    else if (_thirdLoginType == LGThirdPartySocialTypeSinaWeibo) {
        [dic setObject:@"weibo" forKey:@"pf"];
    }
    else if (_thirdLoginType == LGThirdPartySocialTypeWechat) {
        [dic setObject:@"weixin" forKey:@"pf"];
    }
    [dic setObject:_thirdLoginId forKey:@"openid"];
    
//    NSInteger gender = -1;
//    if (_gender == ESGenderFemale) {
//        gender = 0;
//    } else if (_gender == ESGenderMale) {
//        gender = 1;
//    } else if (_gender == ESGenderUnknown) {
//        gender = -1;
//    }
    
    [dic setValue:_nickName forKey:@"nickname"];
//    [dic setValue:@(gender) forKey:@"gender"];
    [dic setValue:_avatorURLStr forKey:@"avatar"];
    
    return dic;
}


@end
