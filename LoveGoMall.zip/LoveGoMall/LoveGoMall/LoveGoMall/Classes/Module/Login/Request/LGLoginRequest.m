//
//  LGLoginRequest.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGLoginRequest.h"

@implementation LGLoginRequest


- (instancetype)initWithAccount:(nonnull NSString *)account password:(nonnull NSString *)pwd
{
    self = [super init];
    if (self) {
        self.account = account;
        self.pwd = pwd;
    }
    return self;
}

- (NSString *)requestUrl {
    return @"/doctor/login";
}


- (id)requestArgument {
    NSMutableDictionary * dic =
    [NSMutableDictionary dictionaryWithDictionary:@{
                                                    @"account": _account,
                                                    @"password": _pwd
                                                    }];
    
    return dic;
    
}



@end
