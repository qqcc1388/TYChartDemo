//
//  LGThirdPartRequest.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGRequest.h"

@interface LGThirdPartLoginRequest : LGRequest


@property (strong, nonatomic) NSString *thirdLoginId;
@property (assign, nonatomic) LGThirdPartySocialType thirdLoginType;

@property (strong, nonatomic) NSString * nickName;
//@property (assign, nonatomic) ESGender gender;
@property (strong, nonatomic) NSString * avatorURLStr;

@end
