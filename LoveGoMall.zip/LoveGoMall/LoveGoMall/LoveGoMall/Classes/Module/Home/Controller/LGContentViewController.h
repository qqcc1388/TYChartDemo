//
//  LGContentViewController.h
//  LoveGoMall
//
//  Created by tiny on 16/7/28.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGCollectionViewController.h"

@interface LGContentViewController : LGCollectionViewController

@end
