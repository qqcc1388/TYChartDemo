//
//  LGHomePageViewController.m
//  LoveGoMall
//
//  Created by tiny on 16/7/28.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGHomePageViewController.h"
#import "LGContentViewController.h"

@interface LGHomePageViewController ()
@property (nonatomic, strong)  NSArray *menuList;
@end

@implementation LGHomePageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    //    self.magicView.bounces = YES;
    //    self.magicView.headerHidden = NO;
    //    self.magicView.itemSpacing = 20.f;
    //    self.magicView.switchEnabled = YES;
    //    self.magicView.separatorHidden = NO;
    self.magicView.itemScale = 1.2;
    self.magicView.headerHeight = 40;
    self.magicView.navigationHeight = 40;
    self.magicView.againstStatusBar = YES;
    //    self.magicView.sliderExtension = 5.0;
    //    self.magicView.switchStyle = VTSwitchStyleStiff;
    //    self.magicView.navigationInset = UIEdgeInsetsMake(0, 50, 0, 0);
    self.magicView.headerView.backgroundColor = RGBCOLOR(243, 40, 47);
    self.magicView.navigationColor = [UIColor whiteColor];
    self.magicView.layoutStyle = VTLayoutStyleDefault;
    self.view.backgroundColor = RGBCOLOR(243, 40, 47);
//    [self integrateComponents];
    
    [self addNotification];
    [self generateTestData];
    [self.magicView reloadData];
    
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self.magicView switchToPage:0 animated:YES];
}

#pragma mark - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView
{
    return _menuList;
}

- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex
{
    static NSString *itemIdentifier = @"itemIdentifier";
    UIButton *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (!menuItem) {
        menuItem = [UIButton buttonWithType:UIButtonTypeCustom];
        [menuItem setTitleColor:RGBCOLOR(50, 50, 50) forState:UIControlStateNormal];
        [menuItem setTitleColor:RGBCOLOR(169, 37, 37) forState:UIControlStateSelected];
        menuItem.titleLabel.font = [UIFont fontWithName:@"Helvetica" size:15.f];
    }
    // 默认会自动完成赋值
    //    NSString *title = _menuList[itemIndex];
    //    [menuItem setTitle:title forState:UIControlStateNormal];
    return menuItem;
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex
{
//    if (0 == pageIndex) {
        static NSString *recomId = @"recom.identifier";
        LGContentViewController *contentViewController = [magicView dequeueReusablePageWithIdentifier:recomId];
        if (!contentViewController) {
            contentViewController = [[LGContentViewController alloc] init];
        }
        return contentViewController;
//    }
//    
//    static NSString *gridId = @"grid.identifier";
//    VTGridViewController *viewController = [magicView dequeueReusablePageWithIdentifier:gridId];
//    if (!viewController) {
//        viewController = [[VTGridViewController alloc] init];
//    }
//    return viewController;
}

#pragma mark - VTMagicViewDelegate
- (void)magicView:(VTMagicView *)magicView viewDidAppeare:(UIViewController *)viewController atPage:(NSUInteger)pageIndex
{
    //    NSLog(@"index:%ld viewDidAppeare:%@", (long)pageIndex, viewController.view);
}

- (void)magicView:(VTMagicView *)magicView viewDidDisappeare:(UIViewController *)viewController atPage:(NSUInteger)pageIndex
{
    //    NSLog(@"index:%ld viewDidDisappeare:%@", (long)pageIndex, viewController.view);
}

- (void)magicView:(VTMagicView *)magicView didSelectItemAtIndex:(NSUInteger)itemIndex
{
    //    NSLog(@"didSelectItemAtIndex:%ld", (long)itemIndex);
}

#pragma mark - actions
- (void)subscribeAction
{
    NSLog(@"subscribeAction");
    // against status bar or not
    //    self.magicView.againstStatusBar = !self.magicView.againstStatusBar;
    [self.magicView setHeaderHidden:!self.magicView.isHeaderHidden duration:0.35];
}

#pragma mark - functional methods
- (void)generateTestData
{
    NSMutableArray *menuList = [[NSMutableArray alloc] initWithCapacity:24];
    [menuList addObject:@"推荐"];
    NSString *title = @"省份";
    for (int index = 0; index < 20; index++) {
        [menuList addObject:[NSString stringWithFormat:@"%@%d",title,index]];
    }
    _menuList = menuList;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
