//
//  LGRequest.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import <YTKRequest.h>

#define LGIsRequestSuccess(dic) ([LGRequest isRequestSuccessFromRequestResponseData:dic])
#define LGResponseMessage(dic) ([LGRequest messageFromRequestResponseData:dic])
#define LGResponseErrorCode(dic) ([LGRequest errorCodeFromResponseData:dic])


@interface LGRequest : YTKRequest

+ (BOOL)isRequestSuccessFromRequestResponseData:(NSDictionary *)dic;
+ (NSString *)messageFromRequestResponseData:(NSDictionary *)responseData;
+ (NSInteger)errorCodeFromResponseData:(NSDictionary *)responseData;

@end
