//
//  LGRequest.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGRequest.h"

@implementation LGRequest


//POST or GET
-(YTKRequestMethod)requestMethod
{
    return YTKRequestMethodPost;
}

//timeout
-(NSTimeInterval)requestTimeoutInterval
{
    return 10;
}

//headerField
-(NSDictionary *)requestHeaderFieldValueDictionary
{
    return @{@"ver": APP_VERSION,@"Content-Type":@"application/x-www-form-urlencoded"};

}


+ (BOOL) isRequestSuccessFromRequestResponseData:(NSDictionary *)responseData {
    if ([responseData isKindOfClass:[NSDictionary class]]) {
        return [[responseData objectNotNullForKey:@"result"] boolValue];
    }
    return NO;
}

+ (NSString *) messageFromRequestResponseData:(NSDictionary *)responseData {
    if ([responseData isKindOfClass:[NSDictionary class]]) {
        return [responseData objectNotNullForKey:@"err_msg"];
    }
    return nil;
}

+ (NSInteger)errorCodeFromResponseData:(NSDictionary *)responseData {
    if ([responseData isKindOfClass:[NSDictionary class]] &&
        [[responseData allKeys] containsObject:@"err_reason"]) {
        return [[responseData objectNotNullForKey:@"err_reason"] integerValue];
    }
    return NSNotFound;
}


@end
