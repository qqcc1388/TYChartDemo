//  Created by lixinxing on 14-3-12.
//  Copyright (c) xx-li. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum
{
    LXInfiniteScrollCusViewLoading = 0,
    LXInfiniteScrollCusViewNoMoreData
}LXInfiniteScrollCusViewType;

/**
 加载更多的自定义View
 */
@interface LXInfiniteScrollCusView : UIView

/**
 *  根据 InfiniteScrollCusViewType 初始化一个加载更多功能对应的View
 *
 *  @param frame
 *  @param type   InfiniteScrollCusViewLoading 显示文本"正在加载zhong..",InfiniteScrollCusViewNoMoreData显示“无更多数据。”
 *
 *  @return QFInfiniteScrollCusView 实例
 */
- (id)initWithFrame:(CGRect)frame infiniteScrollType:(LXInfiniteScrollCusViewType)type;

@end
