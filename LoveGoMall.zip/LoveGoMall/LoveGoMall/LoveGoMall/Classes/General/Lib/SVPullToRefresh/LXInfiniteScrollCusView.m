//  Created by lixinxing on 14-3-12.
//  Copyright (c) xx-li. All rights reserved.
//


#import "LXInfiniteScrollCusView.h"

@interface LXInfiniteScrollCusView ()

@property (strong, nonatomic) UILabel * label;
@property (strong, nonatomic) UIActivityIndicatorView * activityView;
@property (assign, nonatomic) LXInfiniteScrollCusViewType type;

@end

@implementation LXInfiniteScrollCusView

- (id)initWithFrame:(CGRect)frame infiniteScrollType:(LXInfiniteScrollCusViewType)type
{
    self = [super initWithFrame:frame];
    if (self) {

        self.type = type;
        
        [self setOpaque:YES];
        [[self superview] bringSubviewToFront:self];
        
        if (self.type == LXInfiniteScrollCusViewLoading)
        {
            [self.activityView setFrame:CGRectMake(self.center.x - 65, 5, 30, 30)];
            [self addSubview:self.activityView];
            self.label.frame = CGRectMake(self.activityView.frame.origin.x + 35, 5, 100, 30);
            [self.label setText:NSLocalizedString(@"loadMore0", @"正在载入...")];
            [self addSubview:self.label];
        }
        else
        {
            self.label.frame = CGRectMake(self.center.x - 50, 5, 100, 30);
            [self.label setText:NSLocalizedString(@"loadMore1", @"无更多数据")];
            [self addSubview:self.label];
        }
    }
    return self;
}

- (UIActivityIndicatorView *)activityView {
    
    if (!_activityView) {
        _activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        [_activityView startAnimating];
    }
    return _activityView;
}

- (UILabel *)label {
    
    if (!_label) {
        _label = [[UILabel alloc] init];
        [_label setTextColor:[UIColor lightGrayColor]];
    }
    return _label;
    
}

- (void) layoutSubviews {
    [super layoutSubviews];
    
    if (self.type == LXInfiniteScrollCusViewLoading)
    {
        self.activityView.hidden = NO;
        [self.activityView setFrame:CGRectMake(self.center.x - 65, 5, 30, 30)];
        [self addSubview:self.activityView];
        self.label.frame = CGRectMake(self.activityView.frame.origin.x + 35, 5, 100, 30);
        [self.label setText:@"正在载入..."];
    }
    else
    {
        if (self.activityView) {
            self.activityView.hidden = YES;
        }
        self.label.frame = CGRectMake(self.center.x - 50, 5, 100, 30);
        [self.label setText:@"无更多数据"];
    }

}


@end
