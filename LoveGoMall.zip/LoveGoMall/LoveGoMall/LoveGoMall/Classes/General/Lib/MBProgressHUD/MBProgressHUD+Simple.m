//
//  MBProgressHUD+Simple.m
//  EEGSmart
//
//  Created by 李新星 on 15/6/18.
//  Copyright (c) 2015年 深圳创达云睿智能科技有限公司. All rights reserved.
//

#import "MBProgressHUD+Simple.h"

@implementation MBProgressHUD (Simple)

#pragma mark 显示信息
+ (void)show:(NSString *)text icon:(NSString *)icon view:(UIView *)view {
    [self hideHUDForView:view animated:YES];
    
    if (view == nil) view = [[UIApplication sharedApplication].windows lastObject];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.userInteractionEnabled = NO;
    hud.labelText = text;
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"MBProgressHUD.bundle/%@", icon]]];
    hud.mode = MBProgressHUDModeCustomView;
    hud.removeFromSuperViewOnHide = YES;
    [hud hide:YES afterDelay:2];
}

+ (void)hideWindowAllHUD {
    UIView * view = [[UIApplication sharedApplication].windows lastObject];
    [self hideAllHUDsForView:view animated:YES];
}


#pragma mark - Public method
#pragma mark 显示错误或成功的自定义信息
+ (void)showError:(NSString *)error toView:(UIView *)view{
    [self show:error icon:@"error.png" view:view];
}

+ (void)showSuccess:(NSString *)success toView:(UIView *)view {
    [self show:success icon:@"success.png" view:view];
}

+ (void)showSuccess:(NSString *)success {
    [self showSuccess:success toView:nil];
}

+ (void)showError:(NSString *)error {
    [self showError:error toView:nil];
}


#pragma mark 显示HUD与文本
+ (MBProgressHUD *)showHUDtoView:(UIView *)view withText:(NSString *)text {
    [self hideHUDForView:view animated:YES];
    if (view == nil) view = [[UIApplication sharedApplication].windows lastObject];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.labelText = text;
    hud.removeFromSuperViewOnHide = YES;
    hud.dimBackground = NO;
    
    return hud;
}

+ (MBProgressHUD *)showHUDWithText:(NSString *)text {
    return [MBProgressHUD showHUDtoView:nil withText:text];
}


#pragma mark 显示纯文本
+ (void) showText:(NSString *)text toView:(UIView *)view yOffset:(float)yOffset{
    if (view == nil) view = [[UIApplication sharedApplication].windows lastObject];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.userInteractionEnabled = NO;
    hud.mode = MBProgressHUDModeText;
    hud.labelText = text;
    hud.margin = 10.f;
    hud.yOffset += yOffset;
    hud.removeFromSuperViewOnHide = YES;
    [hud hide:YES afterDelay:2];
}

+ (void) showText:(NSString *)text toView:(UIView *)view {
    [self showText:text toView:view yOffset:0];
}

+ (void) showText:(NSString *)text yOffset:(float)yOffset{
    [self showText:text toView:nil yOffset:yOffset];
}

+ (void) showText:(NSString *)text{
    [self showText:text yOffset:0];
}


@end
