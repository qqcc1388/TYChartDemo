//
//  MBProgressHUD+Simple.h
//  EEGSmart
//
//  Created by 李新星 on 15/6/18.
//  Copyright (c) 2015年 深圳创达云睿智能科技有限公司. All rights reserved.
//

#import "MBProgressHUD.h"

@interface MBProgressHUD (Simple)

/*----显示错误与成功的自定义HUD------*/
+ (void)showSuccess:(NSString *)success toView:(UIView *)view;
+ (void)showError:(NSString *)error toView:(UIView *)view;
+ (void)showSuccess:(NSString *)success;
+ (void)showError:(NSString *)error;

/*------同时显示HUD与文本提示-------*/
+ (MBProgressHUD *)showHUDtoView:(UIView *)view withText:(NSString *)text;
+ (MBProgressHUD *)showHUDWithText:(NSString *)text;

/*------显示纯文本提示-------*/
/*! yOffset>0 时下移 */
+ (void) showText:(NSString *)text toView:(UIView *)view yOffset:(float)yOffset;
+ (void) showText:(NSString *)text toView:(UIView *)view;
+ (void) showText:(NSString *)text yOffset:(float)yOffset;
+ (void) showText:(NSString *)text;

/*-----隐藏当前Window上的所有HUD，不会对它的子视图做处理-----*/
+ (void)hideWindowAllHUD;

@end
