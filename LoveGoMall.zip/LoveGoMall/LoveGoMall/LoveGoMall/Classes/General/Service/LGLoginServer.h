//
//  LGLoginServer.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  通过历史登录数据登录类型
 */
typedef NS_ENUM(NSInteger, LGHistoryLoginType){
    LGHistoryLoginNone = 0,
    /**
     *  账号登录类型
     */
    LGHistoryLoginAccount = 1,
    /**
     *  第三方登录类型
     */
    LGHistoryLoginAccountThirdParty = 2,
};

typedef void(^LGLoginComplete)(NSError * __nullable error);


@interface LGLoginServer : NSObject


+ (instancetype)sharedLoginServer;

/*! 历史登录类型 */
@property (assign, nonatomic, readonly) LGHistoryLoginType historyLoginType;
@property (assign, nonatomic, readonly) BOOL isLoginSuccess;


- (void)loginWithAccount:(NSString *)act password:(NSString *)pwd complete:(nullable LGLoginComplete)complete;

//- (void)loginWithThirdLoginInfo:(SSDKUser *)user loginType:(ESThirdPartySocialType)loginType complete:(nullable ESLoginComplete)complete;

- (void) deleteAllKeychainLoginInfo;

/**
 *  根据历史登录数据自动登录
 */
- (void) autoLoginComplete:(LGLoginComplete)complete;

- (void) refreshAccountInfoComplete:(nullable LGLoginComplete)complete;

- (void) loginOutShowLoginUIFromViewController:(nullable UIViewController *)vc;



@end
