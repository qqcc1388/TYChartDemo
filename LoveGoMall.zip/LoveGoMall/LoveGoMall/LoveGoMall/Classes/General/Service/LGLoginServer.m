//
//  LGLoginServer.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGLoginServer.h"
#import <SSKeychain.h>
#import "LGLoginRequest.h"
#import "LGThirdPartLoginRequest.h"
#import "LGNavigationController.h"



#define kESSaveAccountKey                               @"kESSaveAccountKey"
#define kESKeychainSaveAccountLoginSeversKey            @"com.brain.PEDoctor.lgoin1"
#define kESKeychainSaveThirdLoginSeversKey              @"com.brain.PEDoctor.lgoin2"

@implementation LGLoginServer


+ (instancetype)sharedLoginServer {
    
    static id singleton = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleton = [[[self class] alloc] init];
    });
    return singleton;
}


- (instancetype)init
{
    self = [super init];
    if (self) {
        NSDictionary * actDic = [[SSKeychain accountsForService:kESKeychainSaveAccountLoginSeversKey] lastObject];
        NSArray * acts = [SSKeychain accountsForService:kESKeychainSaveThirdLoginSeversKey];
        if (actDic) {
            _historyLoginType = LGHistoryLoginAccount;
        }
        else if (acts) {
            _historyLoginType = LGHistoryLoginAccountThirdParty;
        }
        else {
            _historyLoginType = LGHistoryLoginNone;
        }
    }
    return self;
}


#pragma mark - Public method
- (void)loginWithAccount:(NSString *)act password:(NSString *)pwd complete:(nullable LGLoginComplete)complete {
    LGLoginRequest * request = [[LGLoginRequest alloc] initWithAccount:act password:pwd];
    [request startWithCompletionBlockWithSuccess:^(YTKBaseRequest *request) {
        NSDictionary * resultDic = request.responseJSONObject;
        NSError *error = nil;
        if (LGIsRequestSuccess(resultDic)) {
            [self parseLoginRequestData:resultDic];
            [self saveLoginAccount:act password:pwd];
        }
        else {
            error = [NSError errorWithDomain:LGResponseMessage(resultDic) code:-1 userInfo:nil];
        }
        if (complete) {
            complete(error);
        }
    } failure:^(YTKBaseRequest *request) {
        if (complete) {
            complete([NSError errorWithDomain:@"网络异常" code:-1 userInfo:nil]);
        }
    }];
}


//- (void)loginWithThirdLoginInfo:(SSDKUser *)user loginType:(ESThirdPartySocialType)loginType complete:(nullable ESLoginComplete)complete {
//    ESThirdPartLoginRequest * login = [[ESThirdPartLoginRequest alloc] init];
//    login.thirdLoginId = user.uid;
//    login.thirdLoginType = loginType;
//    login.gender = (ESGender)user.gender;
//    login.nickName = user.nickname;
//    login.avatorURLStr = user.icon;
//    
//    [login startWithCompletionBlockWithSuccess:^(YTKBaseRequest *request) {
//        NSDictionary * resultDic = request.responseJSONObject;
//        NSError *error = nil;
//        if (ESIsRequestSuccess(resultDic)) {
//            [self parseLoginRequestData:resultDic];
//            [self saveThirdLoginId:user.uid loginType:loginType];
//        }
//        else {
//            error = [NSError errorWithDomain:ESResponseMessage(resultDic) code:-1 userInfo:nil];
//        }
//        if (complete) {
//            complete(error);
//        }
//    } failure:^(YTKBaseRequest *request) {
//        if (complete) {
//            complete([NSError errorWithDomain:@"网络异常" code:-1 userInfo:nil]);
//        }
//    }];
//}

//删除钥匙串中所有的登录记录
- (void) deleteAllKeychainLoginInfo {
    
    //删除账号登陆数据
    NSArray * acts = [SSKeychain accountsForService:kESKeychainSaveAccountLoginSeversKey];
    for (NSDictionary * actDic in acts) {
        if (actDic && [actDic isKindOfClass:[NSDictionary class]]) {
            BOOL flag = [SSKeychain deletePasswordForService:kESKeychainSaveAccountLoginSeversKey account:[actDic objectForKey:@"acct"]];
            if (!flag) {
                NSLog(@"删除登录数据失败");
            }
        }
    }
    
    //删除第三方登录数据
    NSArray * thirdActs = [SSKeychain accountsForService:kESKeychainSaveThirdLoginSeversKey];
    for (NSDictionary * actDic in thirdActs) {
        if (actDic && [actDic isKindOfClass:[NSDictionary class]]) {
            BOOL flag = [SSKeychain deletePasswordForService:kESKeychainSaveThirdLoginSeversKey account:[actDic objectForKey:@"acct"]];
            if (!flag) {
                NSLog(@"删除第三方登录数据失败");
            }
        }
    }
}

- (void) saveLoginAccount:(NSString *)act password:(NSString *)pwd {
    //保存前删除所有的登录记录
    [self deleteAllKeychainLoginInfo];
    [SSKeychain setPassword:pwd forService:kESKeychainSaveAccountLoginSeversKey account:act];
    
    _historyLoginType = LGHistoryLoginAccount;
}

- (void) saveThirdLoginId:(NSString *)thirdId loginType:(LGThirdPartySocialType)loginType {
    //保存前删除所有的登录记录
    [self deleteAllKeychainLoginInfo];
    NSString * act = [NSString stringWithFormat:@"%@", @(loginType)];
    BOOL flag = [SSKeychain setPassword:thirdId forService:kESKeychainSaveThirdLoginSeversKey account:act];
    if (!flag) {
        NSLog(@"保存第三方登录数据失败");
    }
    _historyLoginType = LGHistoryLoginAccountThirdParty;
}

- (void) autoLoginComplete:(LGLoginComplete)complete {
    
    //账号登录
    NSDictionary * actDic = [[SSKeychain accountsForService:kESKeychainSaveAccountLoginSeversKey] lastObject];
    if (actDic && [actDic isKindOfClass:[NSDictionary class]]) {
        NSString *act = [actDic objectForKey:@"acct"];
        NSString * pw = [SSKeychain passwordForService:kESKeychainSaveAccountLoginSeversKey account:act];
        //使用之前的登录记录进行登录
        if (pw) {
            [self loginWithAccount:act password:pw complete:complete];
        }
    }
    else {
        //第三方登录
        NSArray * acts = [SSKeychain accountsForService:kESKeychainSaveThirdLoginSeversKey];
        NSDictionary * thirdDic = [acts lastObject];
        if (thirdDic && [thirdDic isKindOfClass:[NSDictionary class]]) {
            NSString * act = [thirdDic objectForKey:@"acct"];
            NSString * thirdId = [SSKeychain passwordForService:kESKeychainSaveThirdLoginSeversKey account:act];
            if (thirdId) {
                LGThirdPartySocialType type = [act integerValue];
//                SSDKUser * socialInfo = [SSDKUser new];
//                socialInfo.uid = thirdId;
//                [self loginWithThirdLoginInfo:socialInfo loginType:type complete:complete];
            }
        }
    }
}

- (void) parseLoginRequestData:(NSDictionary *)resultDic {
    //解析获得账号数据
    NSDictionary * jsondDic = [resultDic objectNotNullForKey:@"data"];
//    _account = [ESAccount mj_objectWithKeyValues:jsondDic];
    _isLoginSuccess = YES;
    [self refreshAccountInfoComplete:nil];
    
    //环信开始登录
//    [[ESEaseMobServer sharedEaseModServer] loginWithAccount:_account];
    
//    [[NSNotificationCenter defaultCenter] postNotificationName:nESNotificationLoginSucess object:nil];
}

- (void) refreshAccountInfoComplete:(nullable LGLoginComplete)complete {
    
    //    NSAssert(_historyLoginType != ESHistoryLoginNone, @"未登录不能刷新个人数据");
    
//    ESGetAccountInfoRequest *request = [[ESGetAccountInfoRequest alloc] init];
//    [request startWithCompletionBlockWithSuccess:^(YTKBaseRequest *request) {
//        NSDictionary * resultDic = request.responseJSONObject;
//        if (ESIsRequestSuccess(resultDic)) {
//            NSDictionary * dic = [resultDic objectNotNullForKey:@"data"];
//            //            _account.nickname = [dic objectForKey:@"nickname"];
//            _account.avatar = [dic objectForKey:@"avatar"];
//            if (complete) {
//                complete(nil);
//            }
//        }
//        else {
//            if (complete) {
//                complete([NSError errorWithDomain:ESResponseMessage(resultDic) code:-1 userInfo:nil]);
//            }
//        }
//    } failure:^(YTKBaseRequest *request) {
//        if (complete) {
//            complete(request.requestOperation.error);
//        }
//    }];
    
}


- (void) loginOutShowLoginUIFromViewController:(UIViewController *)viewController {
    
    //退出登录需要清空Cookie
    NSHTTPCookieStorage * myCookie = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie * cookie in [myCookie cookies])
    {
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
    }
    
    //清除钥匙串中的登录信息
    [self deleteAllKeychainLoginInfo];
    
    //发送登出通知
//    [[NSNotificationCenter defaultCenter] postNotificationName:nESNotificationLoginOutSucess object:nil];
    
    //登出清除授权信息
//    [ShareSDK cancelAuthorize:SSDKPlatformTypeSinaWeibo];
//    [ShareSDK cancelAuthorize:SSDKPlatformTypeWechat];
//    [ShareSDK cancelAuthorize:SSDKPlatformTypeQQ];
    
    //    [[EaseMob sharedInstance].chatManager asyncLogoffWithUnbindDeviceToken:YES completion:^(NSDictionary *info, EMError *error) {
    //        if (!error && info) {
    //            NSLog(@"退出成功");
    //        } else {
    //            NSLog(@"退出失败 %@ \n %@", info, error);
    //        }
    //    } onQueue:nil];
    
    if (viewController == nil) {
        viewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    }
    
//    ESLoginVC * vc = [[ESLoginVC alloc] init];
//    ESNavigationController * navVC = [[ESNavigationController alloc] initWithRootViewController:vc];
//    [viewController presentViewController:navVC animated:YES completion:nil];
}




@end
