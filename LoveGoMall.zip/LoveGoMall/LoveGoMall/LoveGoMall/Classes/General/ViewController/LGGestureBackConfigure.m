//
//  LGGestureBackConfigure.m
//  PEPatient
//
//  Created by 李新星 on 16/4/7.
//  Copyright © 2016年 EEGSmart. All rights reserved.
//

#import "LGGestureBackConfigure.h"

@interface LGGestureBackConfigure ()<UIGestureRecognizerDelegate>


@end

@implementation LGGestureBackConfigure

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (LGGestureBackConfigure *)initWithNavigationController:(UINavigationController *)navCtl
                                           forGestureBack:(BOOL)canGestureBack
{
    self = [super init];
    if (self) {
        _navCtl = navCtl;
        _canGestureBack = canGestureBack;
        if (_canGestureBack) {
            _navCtl.interactivePopGestureRecognizer.delegate = self;
        }
        _navCtl.interactivePopGestureRecognizer.enabled = _canGestureBack;
    }
    return self;
}

- (void)setCanGestureBack:(BOOL)canGestureBack {
    _canGestureBack = canGestureBack;
    if (_canGestureBack) {
        _navCtl.interactivePopGestureRecognizer.delegate = self;
    }
    _navCtl.interactivePopGestureRecognizer.enabled = _canGestureBack;
}

#pragma mark - Delegate
#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isKindOfClass:[UISlider class]]) {
        return NO;
    }
    return YES;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    //在Root界面不能使用手势返回，防止出栈异常
    if (_navCtl.viewControllers.count < 2) {
        return NO;
    } else {
        return YES;
    }
}

//同时接受多个手势
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

//UIScreenEdgePanGestureRecognizer 不与其他的手势同时触发
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldBeRequiredToFailByGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return [gestureRecognizer isKindOfClass:UIScreenEdgePanGestureRecognizer.class];
}

@end
