//
//  LGTableViewCotroller.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//  所有的tableview都继承与这个控制器

#import "LGTableViewCotroller.h"
#import <TPKeyboardAvoidingTableView.h>  //自动管理键盘
#import "LXInfiniteScrollCusView.h"



@interface LGTableViewCotroller ()

@property (assign, nonatomic) UITableViewStyle tableViewStyle;
@property (copy, nonatomic) void(^scrollBlock)(CGFloat beyondHeight, LGTableViewCotroller * ctl);


@end

@implementation LGTableViewCotroller
@synthesize tableView = _tableView;
/**
    1. 所有的tableview都继承与这个控制器
    2. 初始化所有tableview都拥有的属性
    3. 集成上下拉刷新 
    4. 集成刷新数据为空的情况下的UI提示
 */

#pragma mark - Life cycle
- (instancetype)initWithTableViewStyle:(UITableViewStyle)style
{
    self = [super init];
    if (self) {
        self.tableViewStyle = style;
    }
    return self;
}

-(void)loadView
{
    self.view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    _tableView = [[TPKeyboardAvoidingTableView alloc] initWithFrame:self.view.bounds style:self.tableViewStyle];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    __weak __typeof__ (self) wself = self;
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        __strong __typeof (wself) sself = wself;
        make.edges.equalTo(sself.view);
    }];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    _dataArr = [NSMutableArray array];
    _currentPage = 1;
    _pageSize = 10;
    _showRefreshHeader = NO;
    _showRefreshFooter = NO;
    
    self.tableView.emptyDataSetSource = self;
    self.tableView.emptyDataSetDelegate = self;
    
    //去掉无数据分割线
    self.tableView.tableFooterView = [UIView new];
    
    //添加上下拉刷新
    __weak __typeof__ (self) wself = self;
    [_tableView addPullToRefreshWithActionHandler:^{
        __strong __typeof (wself) sself = wself;
        [sself tableViewDidTriggerHeaderRefresh];
    }];
    [_tableView addInfiniteScrollingWithActionHandler:^{
        __strong __typeof (wself) sself = wself;
        [sself tableViewDidTriggerFooterRefresh];
    }];
    
    [_tableView.pullToRefreshView setTitle:@"下拉刷新"
                                  forState:SVPullToRefreshStateStopped];
    [_tableView.pullToRefreshView setTitle:@"松手立即加载"
                                  forState:SVPullToRefreshStateTriggered];
    [_tableView.pullToRefreshView setTitle:@"加载中..."
                                  forState:SVPullToRefreshStateLoading];
    [_tableView.pullToRefreshView setTextColor:[UIColor lightGrayColor]];
    [_tableView.infiniteScrollingView setCustomView:[[LXInfiniteScrollCusView alloc] initWithFrame:CGRectMake(10, 10, _tableView.frame.size.width - 20, 40) infiniteScrollType:LXInfiniteScrollCusViewLoading] forState:SVInfiniteScrollingStateTriggered];
    [_tableView.infiniteScrollingView setCustomView:[[LXInfiniteScrollCusView alloc] initWithFrame:CGRectMake(10, 10, _tableView.frame.size.width - 20, 40) infiniteScrollType:LXInfiniteScrollCusViewNoMoreData] forState:SVInfiniteScrollingStateStopped];
    [_tableView.infiniteScrollingView setCustomView:[[LXInfiniteScrollCusView alloc] initWithFrame:CGRectMake(10, 10, _tableView.frame.size.width - 20, 40) infiniteScrollType:LXInfiniteScrollCusViewLoading] forState:SVInfiniteScrollingStateLoading];
    
    _tableView.showsInfiniteScrolling = _showRefreshFooter;
    _tableView.showsPullToRefresh = _showRefreshHeader;

    
}


#pragma mark - setter

- (void)setShowRefreshHeader:(BOOL)showRefreshHeader
{
    if (_showRefreshHeader != showRefreshHeader) {
        _showRefreshHeader = showRefreshHeader;
        self.tableView.showsPullToRefresh = _showRefreshHeader;
    }
}

- (void)setShowRefreshFooter:(BOOL)showRefreshFooter
{
    if (_showRefreshFooter != showRefreshFooter) {
        _showRefreshFooter = showRefreshFooter;
        self.tableView.showsInfiniteScrolling = showRefreshFooter;
    }
}


#pragma mark UITableViewDelegate, UITableViewDataSource
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    return nil;
}

#pragma mark DZNEmptyDataSetDelegate
- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView {
    //默认不显示无数据提示
    return self.canShowEmptyDataSet;
}

- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView
{
    NSMutableDictionary *attributes = [NSMutableDictionary new];
    
    NSString *text = @"暂无数据";
    UIFont *font = [UIFont boldSystemFontOfSize:22.0];
    UIColor *textColor = UIColorHex(0xacafbd);
    
    NSShadow *shadow = [NSShadow new];
    shadow.shadowColor = [UIColor whiteColor];
    shadow.shadowOffset = CGSizeMake(0.0, 1.0);
    
    [attributes setObject:shadow forKey:NSShadowAttributeName];
    [attributes setObject:font forKey:NSFontAttributeName];
    [attributes setObject:textColor forKey:NSForegroundColorAttributeName];
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}

#pragma mark - Public method
/**
 *  下拉刷新事件
 */
- (void)tableViewDidTriggerHeaderRefresh
{
    
}

/**
 *  上拉加载事件
 */
- (void)tableViewDidTriggerFooterRefresh
{
    
}

- (void) judgeShowInfiniteScrollingView {
    
    self.tableView.showsInfiniteScrolling = self.dataArr.count >= self.pageSize;
    
    if (self.dataArr.count == 0) {
        //展示无信息UI
    }
}

- (void) stopRefreshAnimation:(BOOL)isLoadMore {
    if (isLoadMore) {
        [self.tableView.infiniteScrollingView stopAnimating];
    } else {
        [self.tableView.pullToRefreshView stopAnimating];
    }
}



@end
