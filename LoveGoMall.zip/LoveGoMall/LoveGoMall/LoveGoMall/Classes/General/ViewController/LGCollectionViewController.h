//
//  LGCollectionViewController.h
//  LoveGoMall
//
//  Created by tiny on 16/7/28.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGViewController.h"

@interface LGCollectionViewController : LGViewController

@end
