//
//  LGTabbarController.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//  tabbarcontroller

#import "LGTabbarController.h"
#import "LGNavigationController.h"
#import "LGClassifyViewController.h"
#import "LGSearchViewController.h"
#import "LGShoppingCartViewController.h"
#import "LGPersonalCenterViewController.h"

#import "LGHomePageViewController.h"
//#import "LGChatRootViewController.h"
//#import "LGCommunityController.h"
//#import "LGPersonalCenterController.h"



@interface LGTabbarController ()
{
//    LGChatRootViewController * _advisoryVC;
//    LGPersonalCenterController* _mineVC;
}

@property (strong, nonatomic) UIView * dotView;  //小红点

@end

@implementation LGTabbarController

/*处理各种业务逻辑

 1.版本新特性设计 -- 欢迎页面
 2.登录逻辑 a第一次登录 b自动登录
 3.控制器接受到推送消息可以在这里设置tabbarItem小红点
 */


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //添加需要的通知
    
    //判断是否是第一次打开app
    
    //判断是否需要登录 - 是否是自动登录
    
    //加载tabbar控制器
    [self loadViewControllers];

}

- (void)viewDidAppear:(BOOL)animated {
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        ESLoginServer *loginServer = [ESLoginServer sharedLoginServer];
//        ESHistoryLoginType type = loginServer.historyLoginType;
//        if (type == ESHistoryLoginNone) {  //没有登录过，跳转到登录界面
//            [self showLoginUIWithAnimation:YES];
//        }
//        else {  //已经登录过 自动登录
//            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//            [loginServer autoLoginComplete:^(NSError * _Nullable error) {
//                [hud hide:YES];
//                [hud removeFromSuperview];
//                if (error) {
//                    [self showLoginUIWithAnimation:YES];
//                }
//            }];
//        }
//    });
    [super viewDidAppear:animated];
    
}

- (UIView *)dotView {
    if (!_dotView) {
        _dotView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 5)];
        [_dotView.layer setBorderWithColor:nil width:0 cornerRadius:2.5];
        _dotView.backgroundColor = [UIColor redColor];
    }
    return _dotView;
}


- (void) showLoginUIWithAnimation:(BOOL)isAnimation {
//    ESLoginVC * loginVC = [[ESLoginVC alloc] init];
//    ESNavigationController * vc = [[ESNavigationController alloc] initWithRootViewController:loginVC];
//    [self presentViewController:vc animated:isAnimation completion:nil];
}


- (void) loadViewControllers {
    
    LGHomePageViewController* homepageVC = [[LGHomePageViewController alloc] init];
    homepageVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"首页"
                                                          image:[self renderImageWithName:@"tabbar_homepage_nor"]
                                                  selectedImage:[self renderImageWithName:@"tabbar_homepage_sel"]];
    homepageVC.title = @"首页";
    
    LGClassifyViewController * classifyVC = [[LGClassifyViewController alloc] init];
    classifyVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"分类"
                                                          image:[self renderImageWithName:@"tabbar_advisory_nor"]
                                                  selectedImage:[self renderImageWithName:@"tabbar_advisory_sel"]];
    classifyVC.title = @"分类";
    
//    _advisoryVC = advisoryVC;
    //
    LGSearchViewController * searchVC = [[LGSearchViewController alloc] init];
    searchVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"搜索"
                                                           image:[self renderImageWithName:@"tabbar_community_nor"]
                                                   selectedImage:[self renderImageWithName:@"tabbar_community_sel"]];
    searchVC.title = @"搜索";
    
    LGShoppingCartViewController* shoppingCartVC = [[LGShoppingCartViewController alloc] init];
    shoppingCartVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"购物车"
                                                      image:[self renderImageWithName:@"tabbar_mine_nor"]
                                              selectedImage:[self renderImageWithName:@"tabbar_mine_sel"]];
    shoppingCartVC.title = @"购物车";
    
    LGPersonalCenterViewController* personalCenterVC = [[LGPersonalCenterViewController alloc] init];
    personalCenterVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"我的乐富"
                                                      image:[self renderImageWithName:@"tabbar_mine_nor"]
                                              selectedImage:[self renderImageWithName:@"tabbar_mine_sel"]];
    personalCenterVC.title = @"我的乐富";
    
//    _mineVC = mineVC;
    self.viewControllers = @[
                             [[LGNavigationController alloc] initWithRootViewController:homepageVC],
                             [[LGNavigationController alloc] initWithRootViewController:classifyVC],
                             [[LGNavigationController alloc] initWithRootViewController:searchVC],
                             [[LGNavigationController alloc] initWithRootViewController:shoppingCartVC],
                            [[LGNavigationController alloc] initWithRootViewController:personalCenterVC],
                             ];
    
//    [self.tabBar setBackgroundImage:[UIImage imageWithColor:ESThemeColor]];
    
//    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor]}
//                                             forState:UIControlStateNormal];
//    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : UIColorHex(0x355D9B)}
//                                             forState:UIControlStateSelected];
    //advisoryVC.tabBarItem.badgeValue = @"10";
//    UIView * mineTabBarView = [_mineVC.tabBarItem valueForKey:@"_view"];
//    [mineTabBarView addSubview:self.dotView];
//    [self.dotView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.width.mas_equalTo(5);
//        make.height.mas_equalTo(5);
//        make.top.equalTo(mineTabBarView).with.offset(5);
//        make.centerX.equalTo(mineTabBarView).with.offset(12);
//    }];
//    _dotView.hidden = YES;
    
}

#pragma mark - Private method
- (UIImage *)renderImageWithName:(NSString *)imageName {
    return [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}





@end
