//
//  LGWebViewController.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGWebViewController.h"

@interface LGWebViewController ()

@end

@implementation LGWebViewController

#pragma mark - Life Cycles

- (void)loadView
{
    UIWebView *contentView = [[UIWebView alloc] init];
    contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    contentView.backgroundColor = [UIColor colorWithRed:0.92f green:0.92f blue:0.92f alpha:1];
    contentView.scalesPageToFit = YES;
    contentView.delegate = self;
    self.view = contentView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (self.requestUrl) {
        NSString *url = [_requestUrl stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURLRequest *requst = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
        
        UIWebView * webView = (UIWebView *)self.view;
        webView.scalesPageToFit = self.scaleFit;
        [webView loadRequest:requst];
    }
}


#pragma mark - UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [MBProgressHUD showText:@"加载中..."  toView:self.view];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    
    [MBProgressHUD showError:error.localizedDescription toView:self.view];
}

@end
