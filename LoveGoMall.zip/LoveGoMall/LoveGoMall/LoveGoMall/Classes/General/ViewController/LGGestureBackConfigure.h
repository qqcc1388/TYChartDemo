//
//  LGGestureBackConfigure.h
//  PEPatient
//
//  Created by 李新星 on 16/4/7.
//  Copyright © 2016年 EEGSmart. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGGestureBackConfigure : NSObject

@property (assign, nonatomic) BOOL canGestureBack;
@property (weak, nonatomic, readonly) UINavigationController * navCtl;

- (LGGestureBackConfigure *)initWithNavigationController:(UINavigationController *)navCtl
                                           forGestureBack:(BOOL)canGestureBack;

@end

NS_ASSUME_NONNULL_END