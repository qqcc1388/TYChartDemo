//
//  ESWebViewController.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGViewController.h"

@interface LGWebViewController : LGViewController<UIWebViewDelegate>


@property (copy, nonatomic) NSString *requestUrl;

@property (assign, nonatomic) BOOL scaleFit;

@end
