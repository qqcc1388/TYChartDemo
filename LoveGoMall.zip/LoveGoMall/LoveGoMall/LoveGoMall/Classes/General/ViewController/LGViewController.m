//
//  LGViewController.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//  根控制器

#import "LGViewController.h"
#import "LGNavigationController.h"

@interface LGViewController ()

@end

@implementation LGViewController

/**
    1. 所有的控制器都集成于这个根控制器
    2. 初始化所有控制器都需要的属性
    3. 控制器页面跳转自动隐藏tabbar，退出后自动弹出tabbar
    4. 封装网络请求  -- 几乎所有控制器都可能会用到网络请求
    5. 手势返回统一设置
    6. 返回按钮操作
 */

-(void)dealloc
{
    //停止当前的网络请求
    [self.request stop];
    
    NSLog(@"%@-dealloc",self);
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor randomColor];
    if (self.navigationItem && self.navigationController.viewControllers.count > 1) {
        [self setBackBarBtnStyle];
    }
    
    //默认支持手势返回
    _canGestureBack = YES;
}

//更新self.navigationController的手势返回能力
- (void) updateGestureBackAbility {
    LGNavigationController * navCtl = (LGNavigationController *)self.navigationController;
    if (navCtl) {
        navCtl.canGestureBack = _canGestureBack;
    }
}

//设定返回按钮样式
- (void)setBackBarBtnStyle {
    UIImage * norImge = [UIImage imageNamed:@"navigationbar_back_nor"];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:norImge style:UIBarButtonItemStyleDone target:self action:@selector(backBarBtnClick:)];
}

#pragma mark - Public method
- (void)backBarBtnClick:(UIBarButtonItem *) sender
{
    if (self.navigationController) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self updateGestureBackAbility];
}



@end
