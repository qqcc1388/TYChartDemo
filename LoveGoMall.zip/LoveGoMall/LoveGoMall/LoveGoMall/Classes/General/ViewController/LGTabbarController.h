//
//  LGTabbarController.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LGTabbarController : UITabBarController

@end
