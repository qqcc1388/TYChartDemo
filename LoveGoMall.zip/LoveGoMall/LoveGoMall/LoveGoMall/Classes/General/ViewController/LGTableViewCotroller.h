//
//  LGTableViewCotroller.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGViewController.h"
#import <UIScrollView+EmptyDataSet.h>
#import "SVPullToRefresh.h"

NS_ASSUME_NONNULL_BEGIN

@interface LGTableViewCotroller : LGViewController<UITableViewDataSource, UITableViewDelegate, DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>

/**
 *  初始化self.view 上添加一个 UITableView的视图控制器
 *
 *  @param style UITableView 的样式
 *
 *  @return LGViewController 的实例
 */
- (instancetype)initWithTableViewStyle:(UITableViewStyle)style;

@property (strong, nonatomic,readonly) UITableView * tableView;

@property (strong, nonatomic) NSMutableArray * dataArr;

/*! 当前是第几页， 默认为1， 接口定义从1开始递增 */
@property (assign, nonatomic) NSInteger currentPage;

/*! 一页数据的多少， 默认为15 */
@property (assign, nonatomic) NSInteger pageSize;

@property (nonatomic, assign) BOOL showRefreshHeader;//是否支持下拉刷新
@property (nonatomic, assign) BOOL showRefreshFooter;//是否支持上拉加载

/*! 无数据提示界面是否可以展示，默认为NO */
@property (assign, nonatomic) BOOL canShowEmptyDataSet;

- (void)tableViewDidTriggerHeaderRefresh;
- (void)tableViewDidTriggerFooterRefresh;

- (void) judgeShowInfiniteScrollingView;

- (void) stopRefreshAnimation:(BOOL)isLoadMore;

@end

NS_ASSUME_NONNULL_END
