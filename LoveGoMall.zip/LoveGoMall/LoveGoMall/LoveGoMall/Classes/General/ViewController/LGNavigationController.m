//
//  LGNavigationController.m
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import "LGNavigationController.h"
#import "LGGestureBackConfigure.h"

@interface LGNavigationController ()

@property (strong, nonatomic) LGGestureBackConfigure * gestureBackConfig;


@end

@implementation LGNavigationController

/**
    1.全局设置导航控制器的属性
    2.导航控制器返回手势处理
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    //手势处理
    _gestureBackConfig = [[LGGestureBackConfigure alloc] initWithNavigationController:self forGestureBack:YES];
    
     [self commonInit];

}


#pragma mark - Setter and getter
- (void)setCanGestureBack:(BOOL)canGestureBack {
    if (_canGestureBack == canGestureBack) {
        return;
    }
    _canGestureBack = canGestureBack;
    _gestureBackConfig.canGestureBack = _canGestureBack;
}


#pragma mark private method
- (void) commonInit {
    
    self.navigationBar.translucent = NO;
    
    //取消返回按钮的文本
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(0, -60)
                                                         forBarMetrics:UIBarMetricsDefault];
    
    [self.navigationBar setBackgroundImage:[UIImage imageWithColor:ESThemeColor] forBarMetrics:UIBarMetricsDefault];
    [self.navigationBar setShadowImage:[UIImage new]];
    
    NSDictionary *textAttributes = nil;
    textAttributes = @{ NSForegroundColorAttributeName: [UIColor whiteColor], NSFontAttributeName:[UIFont systemFontOfSize:20] };
    self.navigationBar.titleTextAttributes = textAttributes;
    self.navigationBar.tintColor = [UIColor whiteColor];
}



@end
