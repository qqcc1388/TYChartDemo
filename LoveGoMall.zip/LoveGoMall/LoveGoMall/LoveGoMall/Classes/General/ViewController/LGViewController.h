//
//  LGViewController.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LGRequest.h"

@interface LGViewController : UIViewController

@property (strong,nonatomic, nullable) LGRequest * request;

/**
 *  当前页面能否手势返回，默认为YES
 *  注：当self.navigationController = nil 时是无效的。
 */
@property (assign, nonatomic) BOOL canGestureBack;

- (void)backBarBtnClick:(nullable UIBarButtonItem *) sender;


@end
