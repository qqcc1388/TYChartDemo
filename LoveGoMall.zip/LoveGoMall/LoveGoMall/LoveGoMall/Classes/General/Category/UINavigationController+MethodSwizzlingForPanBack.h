

#import <UIKit/UIKit.h>

/**
 *  用于全局的手势返回、防止在pushViewController的动画过程中触发滑动返回导致的crash
 */
@interface UINavigationController (MethodSwizzlingForPanBack)

@end
