//
//  YTKNetworkAgent+Serializer.m
//  GegedaTeacher
//
//  Created by 李新星 on 15/7/29.
//  Copyright (c) 2015年 深圳创达云睿智能科技有限公司. All rights reserved.
//

#import "YTKNetworkAgent+Serializer.h"
#import <AFHTTPSessionManager.h>
#import <objc/runtime.h>

@implementation YTKNetworkAgent (Serializer)


+(void)load {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Method ovr_initMethod = class_getInstanceMethod([self class], @selector(init));
        Method swz_initMethod = class_getInstanceMethod([self class], @selector(swizzlingForSetSerializer_init));
        method_exchangeImplementations(ovr_initMethod, swz_initMethod);
    });
    
}


- (id) swizzlingForSetSerializer_init {
    
    id swz_self = [self swizzlingForSetSerializer_init];
    AFHTTPRequestOperationManager * manager = [swz_self valueForKey:@"manager"];
    if (manager && [manager isKindOfClass:[AFHTTPRequestOperationManager class]]) {
        //start xx-li
        NSSet * contentSet = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/plain", @"text/html", nil];
        manager.responseSerializer.acceptableContentTypes = contentSet;
    }
    else {
        NSLog(@"YTKNetworkAgent+Serializer kvc get AFHTTPRequestOperationManager error");
    }
    
    return swz_self;
}

@end
