//
//  YTKNetworkAgent+Serializer.h
//  GegedaTeacher
//
//  Created by 李新星 on 15/7/29.
//  Copyright (c) 2015年 深圳创达云睿智能科技有限公司. All rights reserved.
//

#import "YTKNetworkAgent.h"

@interface YTKNetworkAgent (Serializer)

@end
