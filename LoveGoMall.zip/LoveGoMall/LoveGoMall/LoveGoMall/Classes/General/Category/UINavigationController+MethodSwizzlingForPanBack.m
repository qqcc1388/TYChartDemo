

#import "UINavigationController+MethodSwizzlingForPanBack.h"
#import <objc/runtime.h>

@implementation UINavigationController (MethodSwizzlingForPanBack)

+(void)load {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        Method ovr_PushMethod = class_getInstanceMethod([self class], @selector(pushViewController:animated:));
        Method swz_PushMethod = class_getInstanceMethod([self class], @selector(swizzlingForPanBack_pushViewController:animated:));
        method_exchangeImplementations(ovr_PushMethod, swz_PushMethod);
        
        Method ovr_PopMethod = class_getInstanceMethod([self class], @selector(popViewControllerAnimated:));
        Method swz_PopMethod = class_getInstanceMethod([self class], @selector(swizzlingForHiddenBar_popViewControllerAnimated:));
        method_exchangeImplementations(ovr_PopMethod, swz_PopMethod);
        
    });
    
}

- (void)swizzlingForPanBack_pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    if (self.viewControllers.count == 0) {
        viewController.hidesBottomBarWhenPushed = NO;
    } else {
        viewController.hidesBottomBarWhenPushed = YES;
    }
    
    self.interactivePopGestureRecognizer.enabled = NO;
    [self swizzlingForPanBack_pushViewController:viewController animated:animated];

}

- (UIViewController *)swizzlingForHiddenBar_popViewControllerAnimated:(BOOL)animated {
    
    if (self.viewControllers.count == 2) {
        UIViewController * ctl = (UIViewController *)[self.viewControllers firstObject];
        ctl.hidesBottomBarWhenPushed = NO;
    }
    
    return [self swizzlingForHiddenBar_popViewControllerAnimated:animated];
    
}

@end
