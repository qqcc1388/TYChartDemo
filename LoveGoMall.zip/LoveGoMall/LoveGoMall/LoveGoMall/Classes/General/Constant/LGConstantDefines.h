//
//  LGConstantDefines.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//  全局常量定义在这里

#ifndef LGConstantDefines_h
#define LGConstantDefines_h


/*-----------------------Host配置----------------------------------*/
#ifdef DEBUG

#define BRBaseUrl @"http://120.24.239.158:558"

#else

#warning 打包前确认HOST地址
#define BRBaseUrl @"http://120.24.239.158:558"

#endif


/*-----------------------全局枚举定义-------------------------------*/






/*---------------------全局的key定义------------------*/








/*-----------------------UI相关定义----------------------------------*/
#define ESThemeColor       [UIColor colorWithRed:0.0 / 255.0 green:156.0 / 255.0 blue:225.0 / 255.0 alpha:1]






/*-----------------------通知中心----------------------------------*/







/*----------------------提示语定义----------------------------------*/
#define ESNetworkError @"网络不给力，请稍后重试"



#endif /* LGConstantDefines_h */
