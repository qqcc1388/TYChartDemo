//
//  LGSimplifyDefines.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//  一些宏方法 宏定义在这里

#ifndef LGSimplifyDefines_h
#define LGSimplifyDefines_h


//用来消除一些地方调用performSelector方法的警告
#define LGSuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)

//block引用
#define WeakSelf(weakSelf) __weak __typeof(&*self)weakSelf = self;


/**
 * 1、添加一个加强的Log方法
 * 2、release 下不显示Log
 */
#ifdef DEBUG
#define LGLog(format, ...) \
do { \
NSLog(@"<%@ : %d : %s>-: %@", \
[[NSString stringWithUTF8String:__FILE__] lastPathComponent], \
__LINE__, \
__FUNCTION__, \
[NSString stringWithFormat:format, ##__VA_ARGS__]); \
} while(0)

#else

#define NSLog(FORMAT, ...) do{ } while(0)
#define LGLog(format, ...) do{ } while(0)
#endif

#endif /* ESSimplifyDefines_h */
