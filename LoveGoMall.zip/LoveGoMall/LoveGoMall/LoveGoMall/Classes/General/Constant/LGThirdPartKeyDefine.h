//
//  LGThirdPartKeyDefine.h
//  LGProjectArchitecture
//
//  Created by tiny on 16/4/26.
//  Copyright © 2016年 tiny. All rights reserved.
//  第三方的Appkey  appId都写在这里

#ifndef LGThirdPartKeyDefine_h
#define LGThirdPartKeyDefine_h


/*---------------------------ShareSDK-------------------------------*/
/*!
 网址：http://sharesdk.mob.com/#/sharesdk
 账号：lixx@eegsmart.com
 备注：第三方分享与登录
 */
#define kESShareSDKAppKey           @"1001537e63dfa"


/*---------------------------微信-------------------------------*/
/*!
 网址：https://open.weixin.qq.com
 账号：wangbr@eegsmart.com
 备注: 微信开放平台申请得到的 appid, 需要同时添加在 URL schema
 
 */
#define kESWechatAppID      @"wx11ffd31c01c53d1d"
#define kESWechatSecret     @"c3f8339be5105fdc5ef9633d7fb072d0"


/*---------------------------QQ-------------------------------*/
/*!
 网址：http://open.qq.com/
 账号：2516887527
 备注：tencent+appID（你在QQ中申请的AppId）
 */
#define kESTencentQQAppID               @"1105135434"   //16进制 41DF074A
#define kESTencentQQAppKey              @"p8BXMdlB5q7tnKAW"
#define kESTencentQQredirectURI         @"http://www.eegsmart.com"


#endif /* LGThirdPartKeyDefine_h */
